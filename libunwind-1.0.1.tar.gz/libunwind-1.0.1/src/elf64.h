#ifndef elf64_h
#define elf64_h

#ifndef ELF_CLASS
#define ELF_CLASS	ELFCLASS64
#endif
#include "elfxx.h"

#endif /* elf64_h */
